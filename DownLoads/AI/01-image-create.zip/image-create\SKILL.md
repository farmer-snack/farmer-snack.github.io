---
name: image-create
description: |
  使用Pollinations.ai免费API生成图像（无需API密钥）。
  当用户想要创建、绘制、生成或制作任何图像、图片、插画或视觉内容时使用此技能。
  同时支持中文触发词如"画一幅画"、"生成图片"、"画图"。
  使用免费的公共API，无需注册——直接调用URL端点即可。
---

# Image Create

Generate images using the free Pollinations.ai API. No API key required.

## Usage

Use `curl` or Python `requests` to call the image endpoint.

### Quick Command

```bash
curl -s -o "output.png" "https://image.pollinations.ai/prompt/URL_ENCODED_PROMPT?width=1024&height=1024&model=flux" --max-time 60
```

### Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `width` | Image width | `1024` |
| `height` | Image height | `1024` |
| `model` | Model to use: `flux`, `turbo` | `flux` |
| `seed` | Seed for reproducibility | random |
| `nologo` | Remove watermark | `true` |

### Prompt Tips

- URL-encode the prompt (English works best)
- Be specific: describe subject, style, lighting, colors, composition
- For Chinese users: write prompts in English for better results

## Examples

### Example 1: Basic image

```bash
curl -s -o "cat.png" "https://image.pollinations.ai/prompt/A%20cute%20orange%20cat%20sitting%20on%20a%20windowsill%20digital%20art" --max-time 60
```

### Example 2: With size and model

```bash
curl -s -o "output.png" "https://image.pollinations.ai/prompt/A%20person%20sleeping%20next%20to%20a%20polar%20bear%20in%20the%20snow%20cinematic%20lighting?width=1024&height=1024&model=flux&nologo=true" --max-time 60
```

### Example 3: Using Python

```python
import requests

prompt = "A beautiful landscape with mountains at sunset"
url = f"https://image.pollinations.ai/prompt/{requests.utils.quote(prompt)}?width=1024&height=1024&model=flux&nologo=true"
resp = requests.get(url, timeout=60)
with open("output.png", "wb") as f:
    f.write(resp.content)
```

## Output

- Saves PNG file locally
- Show the user the file path after generation
- Images are typically 768×768 default, better with explicit width/height params

## Notes

- Free to use, no API key required
- Soft rate limits apply (don't spam)
- English prompts produce best results
- If the image is low quality, try adding style keywords: `cinematic`, `digital art`, `photorealistic`, `professional photography`

---
name: git-update
description: >
  当用户明确要求执行 1) git add .  2) git commit  3) git push 三部曲提交代码时使用此 skill。
  用户可能会说"提交githu"、"帮我推上去"、"git三步走"、"add commit push"、"更新github"、"提交代码"等。
  对于任何涉及将本地更改提交并推送到远程仓库的多步骤 Git 操作，都应考虑使用此 skill。
  注意：这不适用于单个 Git 命令（如只 git status 或只 git pull），仅适用于完整的 add→commit→push 流程。
---

# Git Update Workflow

当用户要求提交代码时，严格按照以下三部曲执行。

## 流程

### 第 1 步：git add .

```bash
git add .
```

### 第 2 步：git commit

先检查是否有文件需要提交：

```bash
git status
```

- 如果有变更，**向用户询问提交信息（commit message）**
- 如果无变更，告知用户"没有需要提交的变更"并停止

收到提交信息后执行：

```bash
git commit -m "{提交信息}"
```

### 第 3 步：git push

先判断远程跟踪的分支名称：

```bash
git branch -vv
```

- 如果跟踪的是 `origin/main`，则推送到 main
- 如果跟踪的是 `origin/master`，则推送到 master
- 如果用户明确指定了分支，使用用户指定的分支

## 重要规则

1. **必须先问 commit message**，不要自己编造
2. 如果 `git status` 显示没有变更，**不要执行 commit 和 push**，直接告知用户
3. 如果用户指定了分支，使用用户指定的分支
4. 推送失败时，将错误信息返回给用户

## 示例对话

用户: "提交githu 流程：1.git add . 2.git commit -m "{提交信息}" 3.git push origin main"
AI: 执行 git add .，然后检查 git status，询问提交信息，commit，最后推送到 origin/main。
